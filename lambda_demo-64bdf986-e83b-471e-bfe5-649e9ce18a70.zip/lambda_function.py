import json
import boto3

def lambda_handler(event, context):
    intent = event['sessionState']['intent']['name']
    if intent == 'query':
        print ('QUERY')
        order_id = event['sessionState']['intent']['slots']['order_id']['value']['originalValue']
        print ("用户意图是" + intent)
        print ("订单号是" + order_id)
    
        dynamodb = boto3.client('dynamodb')
        order = dynamodb.get_item(
            TableName = 'order',
            Key = {
                'id': {
                    'S': order_id
                }
            }
        )    
        order_sku = order['Item']['sku']['S']
        order_status = order['Item']['status']['S']
        print ('商品' + order_sku)
        print ('状态' + order_status)
        response = '您查询的订单' + order_id + '，商品是' + order_sku + '，状态是' + order_status
        print (response)
    
        return {
            'sessionState': {
                'dialogAction': {
                    'type': 'Close'
                },
                'intent': {
                    'name': intent,
                    'state': 'Fulfilled'
                }
            },
            'messages': [
                {
                    'contentType': 'PlainText',
                    'content': response
                }
            ]
        }
    elif intent == 'order':
        print ('ORDER')
        order_sku = event['sessionState']['intent']['slots']['order_sku']['value']['originalValue']
        print ("用户意图是" + intent)
        print ("订购商品是" + order_sku)
        
        #order_count = boto3.resource('dynamodb').Table('order').item_count
        order_count = boto3.resource('dynamodb').Table('order').scan(
            Select = 'COUNT'
        )['Count']
        response = "当前有" + str(order_count) + "个订单"
        print (response)
        order_id = 'order' + str(order_count+1).zfill(3)
        dynamodb = boto3.client('dynamodb')
        order = dynamodb.put_item(
            TableName = 'order',
            Item = {
                'id': {
                    'S': order_id
                },
                'sku': {
                    'S': order_sku
                },
                'status': {
                    'S': '已预订'    
                }
            }
        )    
        
        return {
            'sessionState': {
                'dialogAction': {
                    'type': 'Close'
                },
                'intent': {
                    'name': intent,
                    'state': 'Fulfilled'
                }
            },
            'messages': [
                {
                    'contentType': 'PlainText',
                    'content': '已经预订商品' + order_sku + '，订单号是' + order_id
                }
            ]
        }
    elif intent == 'return':
        print ('RETURN')
        order_id = event['sessionState']['intent']['slots']['order_id']['value']['originalValue']
        print ("用户意图是" + intent)
        print ("订单号是" + order_id)
    
        dynamodb = boto3.client('dynamodb')
        order = dynamodb.get_item(
            TableName = 'order',
            Key = {
                'id': {
                    'S': order_id
                }
            }
        )    
        order_sku = order['Item']['sku']['S']
        order_status = order['Item']['status']['S']
        print ('商品' + order_sku)
        print ('状态' + order_status)
        response = '您查询的订单' + order_id + '，商品是' + order_sku + '，状态是' + order_status
        print (response)
    
        order = dynamodb.update_item(
            TableName = 'order',
            Key = {
                'id': {
                    'S': order_id
                }
            },
            AttributeUpdates = {
                'status': {
                    'Value': {
                        'S': '申请退货'
                    }
                }
            }
        )
        return {
            'sessionState': {
                'dialogAction': {
                    'type': 'Close'
                },
                'intent': {
                    'name': intent,
                    'state': 'Fulfilled'
                }
            },
            'messages': [
                {
                    'contentType': 'PlainText',
                    'content': '您的订单' + order_id + '已经申请退货。'
                }
            ]
        }